var municipios = [

  {
    CodMun: 38001,
    NombreMun: 'Adeje'
  },
  {
    CodMun: 38004,
    NombreMun: 'Arafo'
  },
  {
    CodMun: 38005,
    NombreMun: 'Arico'
  },
  {
    CodMun: 38006,
    NombreMun: 'Arona'
  },
  {
    CodMun: 38010,
    NombreMun: 'Buenavista del Norte'
  },
  {
    CodMun: 38011,
    NombreMun: 'Candelaria'
  },
  {
    CodMun: 38012,
    NombreMun: 'Fasnia'
  },
  {
    CodMun: 38015,
    NombreMun: 'Garachico'
  },
  {
    CodMun: 38017,
    NombreMun: 'Granadilla de Abona'
  },
  {
    CodMun: 38018,
    NombreMun: 'La Guancha'
  },
  {
    CodMun: 38019,
    NombreMun: 'Guía de Isora'
  },
  {
    CodMun: 38020,
    NombreMun: 'Güímar'
  },
  {
    CodMun: 38022,
    NombreMun: 'Icod de Los Vinos'
  },
  {
    CodMun: 38023,
    NombreMun: 'San Cristóbal de La Laguna'
  },
  {
    CodMun: 38025,
    NombreMun: 'La Matanza de Acentejo'
  },
  {
    CodMun: 38026,
    NombreMun: 'La Orotava'
  },
  {
    CodMun: 38028,
    NombreMun: 'Puerto de La Cruz'
  },
  {
    CodMun: 38031,
    NombreMun: 'Los Realejos'
  },
  {
    CodMun: 38032,
    NombreMun: 'El Rosario'
  },
  {
    CodMun: 38034,
    NombreMun: 'San Juan de La Rambla'
  },
  {
    CodMun: 38035,
    NombreMun: 'San Miguel de Abona'
  },
  {
    CodMun: 38038,
    NombreMun: 'Santa Cruz de Tenerife'
  },
  {
    CodMun: 38039,
    NombreMun: 'Santa Úrsula'
  },
  {
    CodMun: 38040,
    NombreMun: 'Santiago del Teide'
  },
  {
    CodMun: 38041,
    NombreMun: 'El Sauzal'
  },
  {
    CodMun: 38042,
    NombreMun: 'Los Silos'
  },
  {
    CodMun: 38043,
    NombreMun: 'Tacoronte'
  },
  {
    CodMun: 38044,
    NombreMun: 'El Tanque'
  },
  {
    CodMun: 38046,
    NombreMun: 'Tegueste'
  },
  {
    CodMun: 38051,
    NombreMun: 'La Victoria de Acentejo'
  },
  {
    CodMun: 38052,
    NombreMun: 'Vilaflor'
  }
]
export { municipios }
